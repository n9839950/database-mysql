Name: Manan Patel
Student ID: n9839950


Please indicate for each task whether it is attempted/works/not attempted. 
If you attempted it but it doesn't run successfully select 'attempted', if it runs, then select 'works', otherwise select 'not attempted.
For Task 5 select either attempted/not attempted.

--------
Task 1
--------
Create database: works
Create tables: works

--------
Task 2
--------
Q1. Works 
Q2. Works
Q3. Works 
Q4. Works
Q5. Works
Q6. Works

--------
Task 3
--------
Insert: works
Delete: works 
Update: works

--------
Task 4
--------
Create Index: works 
Create View:  works 

-------
Task 5 
-------
Attempted 